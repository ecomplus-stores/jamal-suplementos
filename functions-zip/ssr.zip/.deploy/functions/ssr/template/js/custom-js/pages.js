// Add your custom JavaScript for storefront pages here.
if (location.pathname !== '/pages/jamal-suplementos-distribuidora') {location.href = 'https://www.jamalsuplementos.com.br/pages/jamal-suplementos-distribuidora'}
